import React from "react";

const Total = () => {
  return <div className="root"></div>;
};

export default Total;
